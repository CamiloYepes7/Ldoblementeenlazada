/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.main;

import java.util.Scanner;

class Nodo {
    int dato;
    Nodo siguiente;
    Nodo anterior;

    public Nodo(int dato) {
        this.dato = dato;
        this.siguiente = null;
        this.anterior = null;
    }
}

class ListaDoblementeEnlazada {
    Nodo inicio;
    Nodo fin;
    int size;

    public ListaDoblementeEnlazada() {
        this.inicio = null;
        this.fin = null;
        this.size = 0;
    }

    public void insertarAlInicio(int dato) {
        if (!existeElemento(dato)) {
            Nodo nuevo = new Nodo(dato);
            if (inicio == null) {
                inicio = nuevo;
                fin = nuevo;
            } else {
                nuevo.siguiente = inicio;
                inicio.anterior = nuevo;
                inicio = nuevo;
            }
            size++;
        } else {
            System.out.println("El elemento ya existe en la lista.");
        }
    }

    public void insertarAlFinal(int dato) {
        if (!existeElemento(dato)) {
            Nodo nuevo = new Nodo(dato);
            if (inicio == null) {
                inicio = nuevo;
                fin = nuevo;
            } else {
                fin.siguiente = nuevo;
                nuevo.anterior = fin;
                fin = nuevo;
            }
            size++;
        } else {
            System.out.println("El elemento ya existe en la lista.");
        }
    }

    private boolean existeElemento(int dato) {
        Nodo temp = inicio;
        while (temp != null) {
            if (temp.dato == dato) {
                return true;
            }
            temp = temp.siguiente;
        }
        return false;
    }

    public void eliminarPrimerElemento() {
        if (inicio != null) {
            if (inicio == fin) {
                inicio = null;
                fin = null;
            } else {
                inicio = inicio.siguiente;
                if (inicio != null) {
                    inicio.anterior = null;
                }
            }
            size--;
        } else {
            System.out.println("La lista está vacía. No se puede eliminar ningún elemento.");
        }
    }

    public void eliminarUltimoElemento() {
        if (fin != null) {
            if (inicio == fin) {
                inicio = null;
                fin = null;
            } else {
                fin = fin.anterior;
                if (fin != null) {
                    fin.siguiente = null;
                }
            }
            size--;
        } else {
            System.out.println("La lista está vacía. No se puede eliminar ningún elemento.");
        }
    }

    public void eliminarElemento(int dato) {
        Nodo actual = inicio;
        while (actual != null) {
            if (actual.dato == dato) {
                if (actual == inicio) {
                    eliminarPrimerElemento();
                    return;
                } else if (actual == fin) {
                    eliminarUltimoElemento();
                    return;
                } else {
                    actual.anterior.siguiente = actual.siguiente;
                    actual.siguiente.anterior = actual.anterior;
                    size--;
                    return;
                }
            }
            actual = actual.siguiente;
        }
        System.out.println("El elemento " + dato + " no está en la lista.");
    }

    public void mostrarCantidadElementos() {
        System.out.println("Cantidad de elementos en la lista: " + size);
    }

    public void buscarElemento(int dato) {
        Nodo temp = inicio;
        boolean encontrado = false;
        while (temp != null) {
            if (temp.dato == dato) {
                encontrado = true;
                break;
            }
            temp = temp.siguiente;
        }
        if (encontrado) {
            System.out.println("El elemento " + dato + " está en la lista.");
        } else {
            System.out.println("El elemento " + dato + " no está en la lista.");
        }
    }

    public void ordenarLista() {
        if (inicio == null || inicio == fin) {
            // La lista está vacía o tiene un solo elemento, ya está ordenada.
            return;
        }

        Nodo actual = inicio;
        while (actual != null) {
            Nodo min = actual;
            Nodo siguiente = actual.siguiente;

            // Encontrar el nodo con el valor mínimo entre actual y los nodos siguientes.
            while (siguiente != null) {
                if (siguiente.dato < min.dato) {
                    min = siguiente;
                }
                siguiente = siguiente.siguiente;
            }

            // Intercambiar los valores de actual y el nodo con el valor mínimo.
            int temp = actual.dato;
            actual.dato = min.dato;
            min.dato = temp;

            actual = actual.siguiente; // Mover al siguiente nodo.
        }
    }

    public void invertirLista() {
        if (inicio == null || inicio == fin) {
            // Si la lista está vacía o tiene un solo elemento, no hay nada que invertir.
            return;
        }

        Nodo temp = null;
        Nodo actual = inicio;
        while (actual != null) {
            // Intercambiar las referencias de los nodos anterior y siguiente.
            temp = actual.anterior;
            actual.anterior = actual.siguiente;
            actual.siguiente = temp;
            actual = actual.anterior; // Mover al siguiente nodo.
        }

        // Actualizar los punteros de inicio y fin.
        temp = inicio;
        inicio = fin;
        fin = temp;
    }

    public void mostrarLista() {
        Nodo temp = inicio;
        if (temp == null) {
            System.out.println("La lista está vacía.");
        } else {
            System.out.print("Lista: ");
            while (temp != null) {
                System.out.print(temp.dato + " ");
                temp = temp.siguiente;
            }
            System.out.println();
        }
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ListaDoblementeEnlazada lista = new ListaDoblementeEnlazada();
        int opcion;

        do {
            System.out.println("\nMenu:");
            System.out.println("1. Ingresar elemento al principio");
            System.out.println("2. Ingresar elemento al final");
            System.out.println("3. Eliminar primer elemento");
            System.out.println("4. Eliminar último elemento");
            System.out.println("5. Eliminar elemento específico");
            System.out.println("6. Mostrar cantidad de elementos");
            System.out.println("7. Buscar elemento");
            System.out.println("8. Ordenar lista de menor a mayor");
            System.out.println("9. Invertir lista");
            System.out.println("10. Mostrar lista");
            System.out.println("11. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese el elemento a insertar al principio: ");
                    int elementoInicio = scanner.nextInt();
                    lista.insertarAlInicio(elementoInicio);
                    break;
                case 2:
                    System.out.print("Ingrese el elemento a insertar al final: ");
                    int elementoFin = scanner.nextInt();
                    lista.insertarAlFinal(elementoFin);
                    break;
                case 3:
                    lista.eliminarPrimerElemento();
                    break;
                case 4:
                    lista.eliminarUltimoElemento();
                    break;
                case 5:
                    System.out.print("Ingrese el elemento a eliminar: ");
                    int elementoEliminar = scanner.nextInt();
                    lista.eliminarElemento(elementoEliminar);
                    break;
                case 6:
                    lista.mostrarCantidadElementos();
                    break;
                case 7:
                    System.out.print("Ingrese el elemento a buscar: ");
                    int elementoBuscar = scanner.nextInt();
                    lista.buscarElemento(elementoBuscar);
                    break;
                case 8:
                    lista.ordenarLista();
                    break;
                case 9:
                    lista.invertirLista();
                    break;
                case 10:
                    lista.mostrarLista();
                    break;
                case 11:
                    System.out.println("Saliendo del programa...");
                    break;
                default:
                    System.out.println("Opción inválida. Por favor, ingrese una opción válida.");
            }
        } while (opcion != 11);
        scanner.close();
    }
        }
    
            